//
//  MyTableViewController.h
//  TableSectionStatistics
//
//  Created by mac on 12-11-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

/*
   UITableView的折叠效果
 */

#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController

@end
