//
//  AppDelegate.h
//  Notification
//
//  Created by imac  on 13-9-17.
//  Copyright (c) 2013年 imac . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
