//
//  UserEntity.m
//  MicroBlog
//
//  Created by Reese on 13-4-27.
//  Copyright (c) 2013年 北风网www.ibeifeng.com. All rights reserved.
//

#import "UserEntity.h"


@implementation UserEntity

@synthesize userId;
@synthesize userEmail;
@synthesize userPassword;
@synthesize userStatus;
@synthesize userNickname;
@synthesize userLevel;
@synthesize userVerify;
@synthesize userHead;
@synthesize userDescription;

@end
