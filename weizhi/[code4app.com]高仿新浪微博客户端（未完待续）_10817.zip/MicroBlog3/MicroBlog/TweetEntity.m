//
//  TweetEntity.m
//  MicroBlog
//
//  Created by Reese on 13-4-27.
//  Copyright (c) 2013年 北风网www.ibeifeng.com. All rights reserved.
//

#import "TweetEntity.h"


@implementation TweetEntity

@synthesize tweetId;
@synthesize tweetContent;
@synthesize tweetAttachment;
@synthesize isRetweet;
@synthesize timestamp;
@synthesize deviceInfo;
@synthesize commentCount;
@synthesize retweetCount;
@synthesize trendCount;
@synthesize favorCount;
@synthesize attachment;
@synthesize location;
@synthesize locationX;
@synthesize locationY;
@synthesize ownerId;
@synthesize isInSendBox;


@end
