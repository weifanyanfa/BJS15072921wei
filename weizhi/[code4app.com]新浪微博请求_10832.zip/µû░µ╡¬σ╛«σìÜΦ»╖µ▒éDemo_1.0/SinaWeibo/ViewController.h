//
//  ViewController.h
//  SinaWeibo
//
//  Created by Stephy_xue on 13-9-25.
//  Copyright (c) 2013年 Stephy_xue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIScrollView *_scroll;
}

- (IBAction)buttonClick:(id)sender;

@end
